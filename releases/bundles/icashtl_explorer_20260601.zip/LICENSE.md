# Explorer License — ICASHTL Reference Data

This dataset is provided free of charge for evaluation purposes only.

**Permitted:**
- Personal use and internal evaluation
- Non-commercial research and academic analysis

**Not permitted:**
- Commercial use without a paid subscription
- Redistribution or resale of data
- Use in production trading or risk systems

Full terms: contact@icashtl.com
