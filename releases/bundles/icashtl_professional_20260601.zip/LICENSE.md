# Professional License — ICASHTL Reference Data

This dataset is licensed for production use by the purchasing organization.

**Permitted:**
- Production quant systems and trading infrastructure
- Broker research platforms (internal distribution)
- Integration into commercial products (with separate OEM agreement)

**Not permitted:**
- Direct resale of raw data
- Public redistribution without written consent

Full terms and OEM pricing: contact@icashtl.com
